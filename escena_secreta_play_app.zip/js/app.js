document.addEventListener("DOMContentLoaded", () => {
    loadSection('inicio');
});

function loadSection(section) {
    const main = document.getElementById("main-content");

    if (section === 'inicio') {
        fetch('data/movies.json')
            .then(response => response.json())
            .then(movies => {
                let html = "<h2>Películas recientes</h2><div class='movie-list'>";
                movies.forEach(movie => {
                    html += `
                        <div class='movie'>
                            <img src="${movie.thumbnail}" alt="${movie.title}" onclick="playMovie('${movie.video_url}', '${movie.title}')">
                            <h3>${movie.title}</h3>
                            <p>${movie.description}</p>
                        </div>`;
                });
                html += "</div>";
                main.innerHTML = html;
            });
    } else if (section === 'categorias') {
        main.innerHTML = "<h2>Categorías</h2><ul><li>Acción</li><li>Comedia</li><li>Terror</li><li>Drama</li></ul>";
    } else if (section === 'noticias') {
        main.innerHTML = "<h2>Noticias de cine</h2><p>Próximamente...</p>";
    } else if (section === 'juegos') {
        main.innerHTML = "<h2>Juegos de películas</h2><p>Próximamente...</p>";
    } else if (section === 'subir') {
        main.innerHTML = "<h2>Subir tu video</h2><p>Formulario de subida próximamente...</p>";
    }
}

function playMovie(url, title) {
    const main = document.getElementById("main-content");
    main.innerHTML = `
        <h2>Reproduciendo: ${title}</h2>
        <video controls autoplay width="100%">
            <source src="${url}" type="video/mp4">
            Tu navegador no soporta video HTML5.
        </video>
        <button onclick="loadSection('inicio')">⬅ Volver</button>
    `;
}
